import { supabase } from './supabase';
import { Transaction, UserState, SystemState } from '../types';

export const api = {
  // ===== AUTHENTICATION =====
  login: async (email: string, password?: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password: password || 'demo123'
      });

      if (error) {
        console.error('Login error:', error.message);
        return null;
      }

      if (data.user) {
        // Get user profile from profiles table
        let { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', data.user.id)
          .single();

        // If profile doesn't exist, create one
        if (!profile) {
          const { data: newProfile, error: insertError } = await supabase
            .from('profiles')
            .insert({
              id: data.user.id,
              email: data.user.email,
              name: data.user.user_metadata?.name || email.split('@')[0],
              role: 'user',
              is_active: true,
              balance: 0
            })
            .select()
            .single();

          if (insertError) {
            console.error('Profile insert error:', insertError.message);
          } else {
            profile = newProfile;
          }
        }

        return {
          token: data.session?.access_token,
          user: {
            email: profile?.email || data.user.email,
            name: profile?.name || data.user.user_metadata?.name || 'User',
            balance: profile?.balance || 0,
            role: profile?.role || 'user',
            isActive: profile?.is_active ?? true,
            createdAt: profile?.created_at ? new Date(profile.created_at).getTime() : Date.now(),
            trxAddress: profile?.trx_address
          }
        };
      }
      return null;
    } catch (e) {
      console.error('Login error:', e);
      return null;
    }
  },

  register: async (name: string, email: string, password?: string) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password: password || 'demo123',
        options: {
          data: { name }
        }
      });

      if (error) {
        console.error('Register error:', error.message);
        alert(error.message || 'Registration failed');
        return null;
      }

      if (data.user) {
        // Create profile record
        const { error: profileError } = await supabase
          .from('profiles')
          .insert({
            id: data.user.id,
            email: data.user.email,
            name: name,
            role: 'user',
            is_active: true,
            balance: 0
          });

        if (profileError) {
          console.error('Profile creation error:', profileError.message);
        }

        return {
          token: data.session?.access_token,
          user: {
            email: data.user.email,
            name: name,
            balance: 0,
            role: 'user',
            isActive: true
          }
        };
      }
      return null;
    } catch (e) {
      console.error('Register error:', e);
      return null;
    }
  },

  logout: async () => {
    await supabase.auth.signOut();
  },

  getUser: async (email: string) => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('email', email)
        .single();

      if (profile) {
        return {
          email: profile.email,
          name: profile.name,
          balance: profile.balance || 0,
          role: profile.role || 'user',
          isActive: profile.is_active,
          createdAt: new Date(profile.created_at).getTime(),
          trxAddress: profile.trx_address
        };
      }
    } catch (e) {
      console.error('Get user error:', e);
    }
    return null;
  },

  // ===== NOTIFICATIONS =====
  getNotifications: async (email: string) => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email)
        .single();

      if (!profile) return [];

      const { data } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', profile.id)
        .order('created_at', { ascending: false });

      return data || [];
    } catch (e) {
      return [];
    }
  },

  markNotificationRead: async (id: string) => {
    try {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', id);
    } catch (e) {
      console.error('Mark notification read error:', e);
    }
  },

  // ===== TRANSACTIONS =====
  getTransactions: async (email: string) => {
    try {
      if (!email) return [];

      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email)
        .single();

      if (profileError) {
        console.error('getTransactions profile error:', profileError.message);
        return [];
      }
      if (!profile) return [];

      const { data, error: txError } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', profile.id)
        .order('created_at', { ascending: false });

      if (txError) {
        console.error('getTransactions tx error:', txError.message);
        return [];
      }

      return (data || []).map((tx: any) => ({
        id: tx.id,
        type: tx.type?.toLowerCase() || 'unknown',
        amount: tx.amount,
        currency: 'NUSD',
        date: tx.created_at,
        status: tx.status?.toLowerCase() || 'pending',
        title: `${tx.type || 'Unknown'} Transaction`,
        network: tx.network,
        txHash: tx.tx_hash
      }));
    } catch (e: any) {
      console.error('getTransactions exception:', e.message);
      return [];
    }
  },

  // ===== BANK ACCOUNTS =====
  getBankAccounts: async (email: string) => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email)
        .single();

      if (!profile) return [];

      const { data } = await supabase
        .from('bank_accounts')
        .select('*')
        .eq('user_id', profile.id);

      return (data || []).map((acc: any) => ({
        id: acc.id,
        bankName: acc.bank_name,
        iban: acc.iban,
        accountName: acc.account_name,
        addedAt: acc.added_at
      }));
    } catch (e) {
      return [];
    }
  },

  addBankAccount: async (email: string, bankName: string, iban: string, accountName: string) => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email)
        .single();

      if (!profile) return null;

      const { data, error } = await supabase
        .from('bank_accounts')
        .insert({
          user_id: profile.id,
          bank_name: bankName,
          iban,
          account_name: accountName
        })
        .select()
        .single();

      if (error) {
        console.error('Add bank account error:', error);
        return null;
      }

      return {
        id: data.id,
        bankName: data.bank_name,
        iban: data.iban,
        accountName: data.account_name
      };
    } catch (e) {
      return null;
    }
  },

  deleteBankAccount: async (email: string, id: string) => {
    try {
      const { error } = await supabase
        .from('bank_accounts')
        .delete()
        .eq('id', id);

      return !error;
    } catch (e) {
      return null;
    }
  },

  // ===== WITHDRAWAL =====
  createWithdrawal: async (email: string, amount: number, isInstant = false, type = 'withdraw', network?: string, address?: string) => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('id, balance')
        .eq('email', email)
        .single();

      if (!profile) throw new Error('User not found');
      if (profile.balance < amount) throw new Error('Insufficient balance');

      // Create transaction
      const { data: tx, error } = await supabase
        .from('transactions')
        .insert({
          user_id: profile.id,
          type: 'WITHDRAW',
          amount,
          status: 'PENDING',
          network,
          to_address: address
        })
        .select()
        .single();

      if (error) throw new Error(error.message);

      // Deduct from balance
      await supabase
        .from('profiles')
        .update({ balance: profile.balance - amount })
        .eq('id', profile.id);

      return { success: true, transaction: tx };
    } catch (e: any) {
      throw new Error(e.message || 'Withdrawal failed');
    }
  },

  // ===== DEPOSIT =====
  notifyDeposit: async (email: string, amount: number, network: string, txHash?: string, memoCode?: string) => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email)
        .single();

      if (!profile) return { success: false, error: 'User not found' };

      const { error } = await supabase
        .from('transactions')
        .insert({
          user_id: profile.id,
          type: 'DEPOSIT',
          amount,
          status: 'PENDING',
          network,
          tx_hash: txHash
        });

      if (error) return { success: false, error: error.message };

      return { success: true };
    } catch (e) {
      return { success: false, error: 'Connection error' };
    }
  },

  // ===== PENDING APPROVALS (for P2P) =====
  getPendingApprovals: async (email: string) => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email)
        .single();

      if (!profile) return [];

      // Get pending transactions where user is counterparty
      return [];
    } catch (e) {
      return [];
    }
  },

  // ===== PUBLIC ENDPOINTS =====
  getPublicAgents: async () => {
    try {
      const { data } = await supabase
        .from('merchants')
        .select('*')
        .eq('is_agent', true)
        .eq('is_active', true);

      return data || [];
    } catch (e) {
      return [];
    }
  },

  getMerchantBySlug: async (slug: string) => {
    try {
      const { data } = await supabase
        .from('merchants')
        .select('*, departments(*)')
        .eq('slug', slug)
        .single();

      return data;
    } catch (e) {
      return null;
    }
  },

  // ===== ADMIN API (simplified) =====
  getAllUsers: async () => {
    try {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      return (data || []).map((p: any) => ({
        email: p.email,
        name: p.name,
        balance: p.balance,
        role: p.role,
        isActive: p.is_active,
        createdAt: new Date(p.created_at).getTime()
      }));
    } catch (e) {
      return [];
    }
  },

  getAllTransactions: async () => {
    try {
      const { data } = await supabase
        .from('transactions')
        .select('*, profiles(email, name)')
        .order('created_at', { ascending: false });

      return (data || []).map((tx: any) => ({
        id: tx.id,
        type: tx.type,
        amount: tx.amount,
        status: tx.status,
        network: tx.network,
        txHash: tx.tx_hash,
        timestamp: tx.created_at,
        userEmail: tx.profiles?.email,
        userName: tx.profiles?.name
      }));
    } catch (e) {
      return [];
    }
  },

  getSystemStats: async () => {
    try {
      // Get all profiles
      const { data: profiles } = await supabase
        .from('profiles')
        .select('balance, is_active');

      // Get all transactions
      const { data: transactions } = await supabase
        .from('transactions')
        .select('type, amount, status');

      // Get departments count
      const { data: departments } = await supabase
        .from('departments')
        .select('id');

      // Get vaults
      const { data: vaults } = await supabase
        .from('vaults')
        .select('balance');

      // Calculate stats
      const totalUserBalance = profiles?.reduce((sum: number, p: any) => sum + (p.balance || 0), 0) || 0;
      const activeUsers = profiles?.filter((p: any) => p.is_active).length || 0;
      const totalVaultBalance = vaults?.reduce((sum: number, v: any) => sum + (v.balance || 0), 0) || 0;

      const txs = transactions || [];
      const totalTransactions = txs.length;
      const pendingTransactions = txs.filter((t: any) => t.status === 'PENDING').length;

      // Calculate deposits (positive amounts or DEPOSIT type)
      const deposits = txs.filter((t: any) => t.type === 'DEPOSIT' || (t.amount > 0 && t.status === 'COMPLETED'));
      const totalDeposits = deposits.reduce((sum: number, t: any) => sum + Math.abs(t.amount), 0);

      // Calculate withdrawals (negative amounts or WITHDRAW type)
      const withdrawals = txs.filter((t: any) => t.type === 'WITHDRAW' || t.type === 'P2P_SELL' || (t.amount < 0 && t.status === 'COMPLETED'));
      const totalWithdrawals = withdrawals.reduce((sum: number, t: any) => sum + Math.abs(t.amount), 0);

      const totalVolume = txs.reduce((sum: number, t: any) => sum + Math.abs(t.amount || 0), 0);

      return {
        totalUserBalance,
        totalVaultBalance,
        totalDeposits,
        totalWithdrawals,
        vaultDeposits: 0, // TODO: Track vault-specific deposits
        vaultWithdrawals: 0, // TODO: Track vault-specific withdrawals
        pendingTransactions,
        totalTransactions,
        activeUsers,
        departmentCount: departments?.length || 0,
        totalRevenue: 0,
        totalVolume
      };
    } catch (e) {
      console.error('getSystemStats error:', e);
      return {
        totalUserBalance: 0,
        totalVaultBalance: 0,
        totalDeposits: 0,
        totalWithdrawals: 0,
        vaultDeposits: 0,
        vaultWithdrawals: 0,
        pendingTransactions: 0,
        totalTransactions: 0,
        activeUsers: 0,
        departmentCount: 0,
        totalRevenue: 0,
        totalVolume: 0
      };
    }
  },

  toggleUserStatus: async (email: string) => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('id, is_active')
        .eq('email', email)
        .single();

      if (!profile) return { success: false };

      await supabase
        .from('profiles')
        .update({ is_active: !profile.is_active })
        .eq('id', profile.id);

      return { success: true };
    } catch (e) {
      return { success: false };
    }
  },

  approveTransaction: async (txId: string) => {
    try {
      const { data: tx } = await supabase
        .from('transactions')
        .select('*, profiles(id, balance)')
        .eq('id', txId)
        .single();

      if (!tx) return false;

      // Update transaction status
      await supabase
        .from('transactions')
        .update({ status: 'COMPLETED' })
        .eq('id', txId);

      // If deposit, add to user balance
      if (tx.type === 'DEPOSIT') {
        await supabase
          .from('profiles')
          .update({ balance: (tx.profiles.balance || 0) + tx.amount })
          .eq('id', tx.profiles.id);
      }

      return true;
    } catch (e) {
      return false;
    }
  },

  rejectTransaction: async (txId: string) => {
    try {
      const { data: tx } = await supabase
        .from('transactions')
        .select('*, profiles(id, balance)')
        .eq('id', txId)
        .single();

      if (!tx) return false;

      // Update transaction status to CANCELLED
      await supabase
        .from('transactions')
        .update({ status: 'CANCELLED' })
        .eq('id', txId);

      // If withdrawal or P2P sell (money was already deducted), refund user
      if ((tx.type === 'WITHDRAW' || tx.type === 'P2P_SELL') && tx.amount < 0) {
        const refundAmount = Math.abs(tx.amount);
        await supabase
          .from('profiles')
          .update({ balance: (tx.profiles.balance || 0) + refundAmount })
          .eq('id', tx.profiles.id);
      }

      return true;
    } catch (e) {
      console.error('rejectTransaction error:', e);
      return false;
    }
  },

  // ===== DEPARTMENTS =====
  getDepartments: async () => {
    try {
      const { data } = await supabase
        .from('departments')
        .select('*')
        .order('created_at', { ascending: false });

      return data || [];
    } catch (e) {
      return [];
    }
  },

  createDepartment: async (data: { name: string; color: string; category?: string; commissionType?: string; commissionRate?: number }) => {
    try {
      const { data: dept, error } = await supabase
        .from('departments')
        .insert({
          name: data.name,
          color: data.color,
          category: data.category || 'MERCHANT',
          commission_type: data.commissionType || 'PERCENT',
          commission_rate: data.commissionRate || 0
        })
        .select()
        .single();

      if (error) return null;
      return dept;
    } catch (e) {
      return null;
    }
  },

  updateDepartment: async (id: string, data: any) => {
    try {
      const { data: dept, error } = await supabase
        .from('departments')
        .update({
          name: data.name,
          color: data.color,
          category: data.category,
          commission_type: data.commissionType,
          commission_rate: data.commissionRate
        })
        .eq('id', id)
        .select()
        .single();

      if (error) return null;
      return dept;
    } catch (e) {
      return null;
    }
  },

  deleteDepartment: async (id: string) => {
    try {
      const { error } = await supabase
        .from('departments')
        .delete()
        .eq('id', id);
      return !error;
    } catch (e) {
      return false;
    }
  },

  getDepartmentDetail: async (id: string) => {
    try {
      const { data } = await supabase
        .from('departments')
        .select('*')
        .eq('id', id)
        .single();
      return data;
    } catch (e) {
      return null;
    }
  },

  // ===== VAULTS (simplified) =====
  getVaults: async () => {
    try {
      const { data } = await supabase
        .from('vaults')
        .select('*, departments(name, color)');
      return { vaults: data || [] };
    } catch (e) {
      return { vaults: [] };
    }
  },

  getAdminVaults: async () => {
    try {
      const { data } = await supabase
        .from('vaults')
        .select('*, departments(name, color)');
      return { vaults: data || [], ledger: [] };
    } catch (e) {
      return { vaults: [], ledger: [] };
    }
  },

  // ===== STUBS for unused features =====
  getAllRequests: async () => [],
  getAdminLogs: async () => [],
  resetDB: async () => { },
  cryptoDeposit: async () => { },
  findMatches: async () => null,
  lockMatch: async () => false,
  markPaymentSent: async () => { },
  approveRelease: async () => { },
  manualVaultDeposit: async (vaultId: string, amount: number, userEmail: string, network: string, addToUser: boolean) => {
    try {
      // Get current vault balance
      const { data: vault, error: vaultError } = await supabase
        .from('vaults')
        .select('balance')
        .eq('id', vaultId)
        .single();

      if (vaultError || !vault) {
        console.error('Vault not found:', vaultError);
        return false;
      }

      // Update vault balance
      const { error: updateError } = await supabase
        .from('vaults')
        .update({ balance: (vault.balance || 0) + amount })
        .eq('id', vaultId);

      if (updateError) {
        console.error('Failed to update vault balance:', updateError);
        return false;
      }

      // If addToUser is true and userEmail is provided, credit user balance
      if (addToUser && userEmail && userEmail !== 'External Transfer') {
        const { data: profile } = await supabase
          .from('profiles')
          .select('id, balance')
          .eq('email', userEmail)
          .single();

        if (profile) {
          await supabase
            .from('profiles')
            .update({ balance: (profile.balance || 0) + amount })
            .eq('id', profile.id);

          // Create a deposit transaction record
          await supabase
            .from('transactions')
            .insert({
              user_id: profile.id,
              type: 'DEPOSIT',
              amount: amount,
              status: 'COMPLETED',
              network: network
            });
        }
      }

      return true;
    } catch (e) {
      console.error('manualVaultDeposit error:', e);
      return false;
    }
  },
  createP2POrder: async (type: string, amount: number, email: string, iban: string, bankName: string, accountName: string) => {
    try {
      // Get user profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('id, balance')
        .eq('email', email)
        .single();

      if (!profile) return { success: false, error: 'User not found' };
      if (type === 'SELL' && profile.balance < amount) return { success: false, error: 'Insufficient balance' };

      // Create P2P withdrawal transaction
      const { data: tx, error } = await supabase
        .from('transactions')
        .insert({
          user_id: profile.id,
          type: 'P2P_SELL',
          amount: -amount,
          status: 'PENDING',
          memo_code: `${bankName} - ${iban}`
        })
        .select()
        .single();

      if (error) return { success: false, error: error.message };

      // Deduct from balance immediately for P2P sell
      await supabase
        .from('profiles')
        .update({ balance: profile.balance - amount })
        .eq('id', profile.id);

      return {
        success: true,
        orderId: tx.id,
        message: 'P2P order created successfully'
      };
    } catch (e: any) {
      return { success: false, error: e.message };
    }
  },
  getP2POrderStatus: async (orderId: string) => {
    try {
      const { data } = await supabase
        .from('transactions')
        .select('*')
        .eq('id', orderId)
        .single();

      return data ? { status: data.status, match: null } : null;
    } catch (e) {
      return null;
    }
  },
  markP2PPaymentSent: async () => ({ success: false }),
  confirmP2PPaymentReceived: async () => ({ success: false }),
  getMyP2PActivity: async () => ({ orders: [], trades: [] }),
  getAllMerchants: async () => [],
  createMerchant: async () => ({ success: false }),
  updateMerchant: async () => ({ success: false }),
  deleteMerchant: async () => false,
  getDepartmentMerchant: async () => null
};